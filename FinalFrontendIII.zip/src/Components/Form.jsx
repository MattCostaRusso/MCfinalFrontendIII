// eslint-disable-next-line no-unused-vars
import { React, useState } from "react";
import Contact from "../Pages/Contact";

const Form = () => {
  //Aqui deberan implementar el form completo con sus validaciones

  const defaultUser = {
    name: "",
    email: "",
  };
  const [user, setUser] = useState(defaultUser);

  const [error, setError] = useState(false);
  const [show, setShow] = useState(false);
  const [userName, setUserName] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    if (
      user.name.length > 5 &&
      user.email.length > 6 &&
      user.email.includes("@")
    ) {
      setError(false);
      setUserName(user.name);
      setUser(defaultUser);
      setShow(true);
    } else {
      setError(true);
      setShow(false)
    }
  };

  const handleOnChangeName = (event) => {
    setUser({ ...user, name: event.target.value.trim() });
  };

  const handleOnChangeEmail = (event) => {
    setUser({ ...user, email: event.target.value.trim() });
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label>Ingrese su nombre completo</label>
        <input type="text" value={user.name} onChange={handleOnChangeName} />
        <label>Ingrese su correo electrónico</label>
        <input type="text" value={user.email} onChange={handleOnChangeEmail} />
        <button>Enviar</button>
      </form>
      {error && (
        <h5 style={{ color: "red" }}>
          Por favor verifique su información nuevamente
        </h5>
      )}

      {show && (
        <h5>Gracias {userName}, te contactaremos cuanto antes vía mail</h5>
      )}
    </div>
  );
};

export default Form;
