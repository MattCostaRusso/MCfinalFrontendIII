// eslint-disable-next-line no-unused-vars
import React from 'react'
import Form from '../Components/Form'

const Contact = () => {
  return (
    <div>
        <Form/>
    </div>
  )
}

export default Contact