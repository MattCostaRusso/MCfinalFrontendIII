// eslint-disable-next-line no-unused-vars
import React from 'react'
import Card from '../Components/Card'
import { useContextGlobal} from '../Context/ContextProvider'

const Home = () => {

    const {list} = useContextGlobal()
    console.log(list);

    return (
        <div>
            {list.map(item => <Card item={item} key= {item.id}/>)}
        </div>
        )
}

export default Home