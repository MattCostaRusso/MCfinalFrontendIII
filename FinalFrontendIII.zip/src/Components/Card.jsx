// eslint-disable-next-line no-unused-vars
import React from "react";
import { Link } from 'react-router-dom'
import { useContextGlobal } from '../Context/ContextProvider'


const Card = ({item}) => {

  const {favs, dispatch} = useContextGlobal()

  const findFav = favs.find((fav) => fav.id == item.id)
    console.log(findFav)

  const addFav = ()=>{
    // Aqui iria la logica para agregar la Card en el localStorage
    if(findFav){
      const newList = favs.filter((dentist) => dentist.id != item.id)
      console.log('Borrar favorito',newList);
      dispatch({type: 'DELETE_FAV', payload: newList})
      alert(`${item.name} ha sido removido de su lista de favoritos.`) 
    } else{
      dispatch({type: 'ADD_FAV', payload: item})
    }
  }

  return (
    <div style={{display: 'flex', flexDirection: 'column'}} >
      <Link to={'/detail/' + item.id}>
        {/* En cada card deberan mostrar en name - username y el id */}
        <h4>{item.id}</h4>
        <h4>{item.name}</h4>
        <h4>{item.email}</h4>
        </Link>  
        {/* No debes olvidar que la Card a su vez servira como Link hacia la pagina de detalle */}

        {/* Ademas deberan integrar la logica para guardar cada Card en el localStorage */}
      
      <button onClick={addFav}>{findFav ? '🌟' : '⭐'}</button>        
    </div>
  );
};

export default Card;
