import axios from "axios";
import { createContext, useContext, useReducer, useEffect} from "react";
import { reducer } from "../reducers/reducer";

const initialState = {
    list: [],
    favs: JSON.parse(localStorage.getItem('favs') || '[]')
    // theme
}

const UserStates = createContext(initialState)

const Context = ({children}) => {

    const [state, dispatch] = useReducer(reducer, initialState)
    const {list, favs} = state
    console.log(state)
    const url = 'https://jsonplaceholder.typicode.com/users'
    useEffect(() => {
      axios(url)
      .then(res => {
        console.log(res.data);
        dispatch({type: 'GET_DENTISTS', payload: res.data})
      })
      }, [])
  
    useEffect(() => {
      console.log(favs);
      localStorage.setItem('favs', JSON.stringify(favs))
      }, [favs])

    return (
        <UserStates.Provider value={{list, favs, dispatch}}>
            {children}
        </UserStates.Provider>
    )
}

export default Context

export const useContextGlobal = () => useContext(UserStates)