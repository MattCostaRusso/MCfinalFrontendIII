/* eslint-disable react-refresh/only-export-components */
import axios from 'axios'
import { createContext, useContext, useReducer, useEffect} from 'react'
import { reducer } from '../Reducers/reducer'

export const ContextGlobal = createContext()

export const initialState = {
  theme: "",
  list: [],
  favs: JSON.parse(localStorage.getItem('favs')) || [],
}


// eslint-disable-next-line react/prop-types
export const ContextProvider = ({ children }) => {
  //Aqui deberan implementar la logica propia del Context, utilizando el hook useMemo
  // const [state, dispatch] = useReducer(reducer, initialState)
  // const {list, favs} = state
  // //const [theme, dispatch] = useReducer(reducer, inicialState)
  // console.log(state)
  // const url = 'https://jsonplaceholder.typicode.com/users'

  // useEffect(() => {
  //   axios(url)
  //   .then(res => dispatch({type: 'GET_DENTIST', payload: res.data.results}))
  //   }, [])

  // useEffect(() => {
  //   localStorage.setItem('favs', JSON.stringify(state.favs))
  //   }, [state.favs])

    /* 
    useEffect(() => {
    localStorage.setItem('theme', JSON.stringify(state.theme))
    }, [state.theme])
    */

    return (
        //<ContextGlobal.Provider value={{list, favs, dispatch}}>
        <ContextGlobal.Provider value={{}}>
            {children}
        </ContextGlobal.Provider>
    )
}


export default ContextGlobal.Consumer; 


//export const useContextGlobal = () => useContext(ContextGlobal)