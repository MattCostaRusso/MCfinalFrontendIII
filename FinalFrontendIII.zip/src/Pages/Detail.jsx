import axios from 'axios'
// eslint-disable-next-line no-unused-vars
import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'

const Detail = () => {

    const [users, setUsers] = useState({})
    const {id} = useParams()
    const {favs, setFavs} = useState()
    console.log(id)
    const url= 'https://jsonplaceholder.typicode.com/users/' + id

    useEffect(() => {
        const fetchUsers = async () => {
            const res =await axios(url)
            setUsers(res.data)
        }
        fetchUsers()
    }, [])

    return (
        <div>
            <h2>{users.name}</h2>
            <h2>{users.email}</h2>
            <h2>{users.phone}</h2>
            <h2>{users.website}</h2>
            <button onClick={() => setFavs([...favs, users])}>⭐</button>
        </div>
    )
}

export default Detail