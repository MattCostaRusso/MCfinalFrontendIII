// eslint-disable-next-line no-unused-vars
import React from 'react'
import Card from '../Components/Card'
import {useContextGlobal} from '../Context/ContextProvider'


const Favs = () => {

  const {favs} = useContextGlobal()

  return (
    <div>
        {favs.map(fav => <Card item={fav} key={fav.id}/>)}
    </div>
  )
}
export default Favs